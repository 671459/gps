# DAT100 programmeringsprosjekt

Dette repository inneholder startkoden for prosjektet. 
